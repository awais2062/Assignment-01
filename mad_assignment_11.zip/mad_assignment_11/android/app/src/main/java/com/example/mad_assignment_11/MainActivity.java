package com.example.mad_assignment_11;

import io.flutter.embedding.android.FlutterActivity;

public class MainActivity extends FlutterActivity {
}
